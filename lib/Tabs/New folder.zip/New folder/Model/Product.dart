import 'Memory.dart';
import 'Color.dart';

class Product {
  int? id;
  int? price;
  int? sold;
  String? name;
  String? cpu;
  String? ram;
  String? display;
  String? camera;
  String? battery;
  String? system;
  Color? color;
  String? des;
  Memory? memory;
  List<Memory>? memories;

  Product.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    price = json["price"];
    name = json["name"];
    des = json["des"];
    cpu = json["cpu"];
    ram = json["ram"];
    sold = json["sold"];
    display = json["display"];
    battery = json["battery"];
    camera = json["camera"];
    system = json["system"];
    memories =
        (json["memories"] as List).map((e) => Memory.fromJson(e)).toList();
    color = Color.fromJson(json["color"]);
    memory = Memory.fromJson(json["memory"]);
  }
}
