import 'Color.dart';

class Memory {
  int? id;
  String? name;
  List<Color>? colors;

  Memory.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    name = json["name"];
    colors = (json["colors"] as List).map((e) => Color.fromJson(e)).toList();
  }
}