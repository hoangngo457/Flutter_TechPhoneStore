import 'dart:ui';

import 'Memory.dart';

class Color {
  int? id;
  String? name;
  List<String>? imgs;

  Color.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    name = json["name"];
    imgs = List<String>.from(json["imgs"]);
  }
}