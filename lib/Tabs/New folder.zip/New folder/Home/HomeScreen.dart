import 'package:flutter/material.dart';
import 'package:storesalephone/Model/Category.dart';
import 'package:storesalephone/Model/Product.dart';
import 'package:storesalephone/Tabs/Home/HomeSetup.dart';
import 'HomeGenerate.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<StatefulWidget> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  List<Category> brands = [];
  List<Product> products = [];

  Future<void> setUpProcess() async {
    SetUpData setUpData = SetUpData();
    List<Category> listCategory = await setUpData.getDataCategory();
    List<Product> listProducts = await setUpData.getDataProduct();
    setState(() {
      brands = listCategory;
      products = listProducts;
    });
  }

  @override
  void initState() {
    super.initState();
    setUpProcess();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 300,
            decoration: const BoxDecoration(
              color: Colors.indigoAccent,
            ),
            child: Column(
              children: [
                const HomeTitle(),
                const SizedBox(
                  height: 30,
                ),
                const HomeSearch(),
                HomeCategories(brands: brands)
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const HomeCarousel(),
          const Padding(
            padding: EdgeInsets.only(top: 20, left: 10, right: 10, bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Sản phẩm bán chạy",
                  style: TextStyle(fontSize: 16),
                ),
                Text(
                  "Xem tất cả",
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                )
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(color: Colors.grey.shade100),
            child: HomeListProduct(products: products),
          )
        ],
      ),
    );
  }
}
