import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:storesalephone/Model/Category.dart';
import 'package:storesalephone/Model/Product.dart';
import 'package:storesalephone/CommonWidget/CardProduct.dart';
import 'package:storesalephone/Tabs/Cart/CartScreen.dart';
import 'package:storesalephone/Tabs/Detail/DetailSceen.dart';
import 'package:storesalephone/Tabs/Search/SearchScreen.dart';

class HomeSearch extends StatelessWidget {
  const HomeSearch({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: CupertinoSearchTextField(
        placeholder: "Nhập tên điện thoại tại đây",
        style: const TextStyle(fontSize: 12),
        borderRadius: BorderRadius.circular(20),
        backgroundColor: Colors.white,
        padding: const EdgeInsets.all(12),
        onTap: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const SearchProduct()));
        },
      ),
    );
  }
}

class HomeCarousel extends StatefulWidget {
  const HomeCarousel({super.key});

  @override
  State<StatefulWidget> createState() => HomeCarouselState();
}

class HomeCarouselState extends State<HomeCarousel> {
  int currentCarousel = 0;
  final myItems = [
    const Image(
        image: AssetImage("assets/carousel/carousel1.png"), fit: BoxFit.cover),
    const Image(
        image: AssetImage("assets/carousel/carousel2.jpg"), fit: BoxFit.cover),
    const Image(
        image: AssetImage("assets/carousel/carousel3.png"), fit: BoxFit.cover),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider(
          items: myItems.map((i) {
            return Builder(
              builder: (BuildContext context) {
                return Container(
                  width: MediaQuery.of(context).size.width,
                  margin: const EdgeInsets.symmetric(horizontal: 5.0),
                  decoration: BoxDecoration(
                    color: Colors.amber,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: i,
                  ),
                );
              },
            );
          }).toList(),
          options: CarouselOptions(
              autoPlay: true,
              aspectRatio: 2.0,
              height: 200,
              onPageChanged: (index, reason) {
                setState(() {
                  currentCarousel = index;
                });
              }),
        ),
        const SizedBox(
          height: 15,
        ),
        AnimatedSmoothIndicator(
          activeIndex: currentCarousel,
          count: myItems.length,
          effect: const WormEffect(
            dotWidth: 70,
            dotHeight: 5,
            spacing: 5,
          ),
        ),
      ],
    );
  }
}

class HomeTitle extends StatelessWidget {
  const HomeTitle({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.fromLTRB(10, 40, 0, 0),
        alignment: Alignment.bottomLeft,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Một ngày tuyệt vời",
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
                Row(
                  children: [
                    Text(
                      "Nguyễn Minh Khôi",
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Image(
                      image: AssetImage("assets/open-box.png"),
                      width: 27,
                      height: 27,
                    )
                  ],
                ),
              ],
            ),
            InkWell(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Cart())),
              child: Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: SizedBox(
                      child: Stack(
                    children: [
                      const Image(
                        image: AssetImage("assets/shopping-bag-white.png"),
                        width: 25,
                        height: 25,
                      ),
                      Positioned(
                          left: 0,
                          bottom: 0,
                          child: Container(
                            width: 15,
                            height: 15,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle, color: Colors.red),
                            child: const Text(
                              "1",
                              style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                          ))
                    ],
                  ))),
            )
          ],
        ));
  }
}

class HomeCategories extends StatelessWidget {
  const HomeCategories({super.key, required this.brands});
  final List<Category> brands;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(10, 20, 0, 0),
            alignment: Alignment.bottomLeft,
            child: const Text("Thương hiệu phổ biến",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
          ),
          Expanded(
              child: ListView.builder(
            shrinkWrap: true,
            itemCount: brands.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (_, index) {
              return Container(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(60),
                          boxShadow: [
                            BoxShadow(
                              color:
                                  Colors.black.withOpacity(0.1), // Shadow color
                              spreadRadius: 5, // Spread radius
                              blurRadius: 7, // Blur radius
                              offset: const Offset(0,
                                  3), // Offset in x and y axis from the shadow
                            )
                          ]),
                      child: Center(
                        child: Image.network(
                          brands[index].img.toString(),
                          fit: BoxFit.contain,
                          width: 100,
                          height: 100,
                        ),
                      ),
                    ),
                    // const SizedBox(height: 2),
                    // SizedBox(
                    //     width: 50,
                    //     child: Text(
                    //       brands[index].name.toString(),
                    //       style: const TextStyle(color: Colors.white),
                    //       overflow: TextOverflow.ellipsis,
                    //     ))
                  ],
                ),
              );
            },
          ))
        ],
      ),
    );
  }
}

class HomeListProduct extends StatelessWidget {
  const HomeListProduct({super.key, required this.products});
  final List<Product> products;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: products.length,
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1.0,
          mainAxisSpacing: 10.0,
          crossAxisSpacing: 10.0,
          mainAxisExtent: 320,
        ),
        itemBuilder: (_, index) {
          return InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          DetailScreen(product: products[index])));
            },
            child: CardProduct(
              product: products[index],
              type: "hot",
            ),
          );
        });
  }
}
