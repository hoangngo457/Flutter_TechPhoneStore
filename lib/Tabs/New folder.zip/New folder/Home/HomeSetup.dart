
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:storesalephone/Model/Category.dart';
import 'package:storesalephone/Model/Product.dart';

class SetUpData  {

  Future<List<Category>> getDataCategory() async {
    final String response = await rootBundle.loadString("assets/test.json");
    final data = jsonDecode(response);
    return (data["brand"] as List).map((e) => Category.fromJson(e)).toList();
  }


  Future<List<Product>> getDataProduct() async {
    final String response = await rootBundle.loadString("assets/test.json");
    final data = jsonDecode(response);
    return (data["product"] as List).map((e) => Product.fromJson(e)).toList();
  }

}